from .spider_runner import WeiboSpiderRunner

__all__ = ['WeiboSpiderRunner'] 