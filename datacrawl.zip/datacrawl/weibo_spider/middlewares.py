import random

class UserAgentMiddleware:
    def __init__(self):
        self.user_agents = [
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0'
        ]
        
        # 添加更多浏览器特征
        self.default_headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'X-Requested-With': 'XMLHttpRequest',
            'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }

    def process_request(self, request, spider):
        # 设置随机User-Agent
        request.headers['User-Agent'] = random.choice(self.user_agents)
        
        # 设置其他请求头
        for key, value in self.default_headers.items():
            if key not in request.headers:
                request.headers[key] = value
                
        # 处理meta中的headers
        if 'headers' in request.meta:
            for key, value in request.meta['headers'].items():
                request.headers[key] = value
            # 删除meta中的headers，避免重复处理
            del request.meta['headers']
                
        # 如果没有在meta中指定headers，则使用默认的Referer和Origin
        if 'weibo.com' in request.url and 'Referer' not in request.headers:
            if 'ajax/statuses/buildComments' in request.url:
                tweet_id = request.url.split('id=')[1].split('&')[0]
                request.headers['Referer'] = f'https://weibo.com/{spider.user_id}/{tweet_id}'
                request.headers['Origin'] = 'https://weibo.com'
            elif 'ajax/statuses/mymblog' in request.url:
                request.headers['Referer'] = f'https://weibo.com/u/{spider.user_id}'
                request.headers['Origin'] = 'https://weibo.com'

class ProxyMiddleware:
    def __init__(self, proxy_list):
        self.proxy_list = proxy_list

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings.getlist('PROXY_LIST'))

    def process_request(self, request, spider):
        if self.proxy_list:
            proxy = random.choice(self.proxy_list)
            request.meta['proxy'] = proxy
            spider.logger.debug(f'Using proxy: {proxy}')

    def process_exception(self, request, exception, spider):
        # 如果代理请求失败，尝试使用其他代理
        if 'proxy' in request.meta:
            proxy = request.meta['proxy']
            if proxy in self.proxy_list:
                self.proxy_list.remove(proxy)
            if self.proxy_list:
                new_proxy = random.choice(self.proxy_list)
                request.meta['proxy'] = new_proxy
                spider.logger.debug(f'Switching to new proxy: {new_proxy}')
                return request 