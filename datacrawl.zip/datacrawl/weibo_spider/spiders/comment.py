import json
import scrapy
from ..items import CommentItem, TweetItem
from .base import BaseSpider
from scrapy.exceptions import IgnoreRequest
import logging

class CommentSpider(BaseSpider):
    name = 'comment'
    
    def start_requests(self):
        # 首先获取用户的微博列表
        url = f'https://weibo.com/ajax/statuses/mymblog?uid={self.user_id}&page=1'
        yield scrapy.Request(
            url=url,
            callback=self.parse_tweets,
            errback=self.errback_httpbin,
            dont_filter=True
        )
        
    def parse_tweets(self, response):
        try:
            data = json.loads(response.text)
            if data.get('ok') == 1:
                tweets = data['data']['list']
                for tweet in tweets:
                    if not self.check_date(tweet['created_at']):
                        continue
                        
                    # 先创建帖子记录
                    tweet_item = TweetItem()
                    tweet_item['_id'] = tweet['id']
                    tweet_item['user_id'] = self.user_id
                    tweet_item['content'] = tweet['text_raw']
                    tweet_item['created_at'] = self.parse_time(tweet['created_at'])
                    tweet_item['retweet_count'] = tweet['reposts_count']
                    tweet_item['comment_count'] = tweet['comments_count']
                    tweet_item['like_count'] = tweet['attitudes_count']
                    tweet_item['read_count'] = tweet.get('reads_count', 0)
                    tweet_item['source'] = tweet.get('source', '')
                    tweet_item['is_long'] = tweet.get('isLongText', False)
                    
                    # 处理图片
                    pictures = []
                    if 'pic_ids' in tweet:
                        for pic_id in tweet['pic_ids']:
                            pictures.append(f'https://wx1.sinaimg.cn/orj960/{pic_id}')
                    tweet_item['pictures'] = pictures
                    
                    # 处理视频
                    if 'page_info' in tweet and tweet['page_info'].get('type') == 'video':
                        tweet_item['video_url'] = tweet['page_info']['media_info']['stream_url']
                    else:
                        tweet_item['video_url'] = ''
                    
                    yield tweet_item
                        
                    # 获取每条微博的评论
                    tweet_id = tweet['id']
                    comment_url = f'https://weibo.com/ajax/statuses/buildComments?flow=0&is_reload=1&id={tweet_id}&is_show_bulletin=2&is_mix=0&count=20&page=1'
                    yield scrapy.Request(
                        url=comment_url,
                        callback=self.parse_comments,
                        errback=self.errback_httpbin,
                        meta={
                            'tweet_id': tweet_id,
                            'retry_times': 0,
                            'headers': {
                                'Referer': f'https://weibo.com/{self.user_id}/{tweet_id}',
                                'Origin': 'https://weibo.com'
                            }
                        },
                        dont_filter=True
                    )
                    
                # 处理下一页微博
                if data['data']['list'] and data['data']['page'] < data['data']['total']:
                    next_page = data['data']['page'] + 1
                    next_url = f'https://weibo.com/ajax/statuses/mymblog?uid={self.user_id}&page={next_page}'
                    yield scrapy.Request(
                        url=next_url,
                        callback=self.parse_tweets,
                        errback=self.errback_httpbin,
                        dont_filter=True
                    )
            else:
                self.logger.error(f"Failed to get tweets: {data.get('msg', 'Unknown error')}")
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error in parse_tweets: {str(e)}")
            self.logger.debug(f"Response text: {response.text[:200]}")  # 只记录前200个字符
                
    def parse_comments(self, response):
        try:
            # 添加详细的日志记录
            self.logger.info(f"Request URL: {response.url}")
            self.logger.info(f"Request Headers: {response.request.headers}")
            self.logger.info(f"Response Status: {response.status}")
            self.logger.info(f"Response Headers: {response.headers}")
            self.logger.info(f"Response Text: {response.text[:500]}")  # 记录前500个字符
            
            data = json.loads(response.text)
            if data.get('ok') == 1:
                comments = data['data']
                for comment in comments:
                    item = CommentItem()
                    item['_id'] = comment['id']
                    item['tweet_id'] = comment['mid']
                    item['user_id'] = comment['user']['id']
                    item['content'] = comment['text_raw']
                    item['created_at'] = self.parse_time(comment['created_at'])
                    item['like_count'] = comment['like_counts']
                    yield item
                    
                # 处理下一页评论
                if data['data'] and data['page'] < data['total']:
                    next_page = data['page'] + 1
                    tweet_id = data['data'][0]['mid']
                    next_url = f'https://weibo.com/ajax/statuses/buildComments?flow=0&is_reload=1&id={tweet_id}&is_show_bulletin=2&is_mix=0&count=20&page={next_page}'
                    yield scrapy.Request(
                        url=next_url,
                        callback=self.parse_comments,
                        errback=self.errback_httpbin,
                        meta={
                            'tweet_id': tweet_id,
                            'retry_times': 0,
                            'headers': {
                                'Referer': f'https://weibo.com/{self.user_id}/{tweet_id}',
                                'Origin': 'https://weibo.com'
                            }
                        },
                        dont_filter=True
                    )
            else:
                self.logger.error(f"Failed to get comments: {data.get('msg', 'Unknown error')}")
                # 如果是权限问题，记录并跳过
                if data.get('msg') == '没有权限':
                    self.logger.warning(f"No permission to access comments for tweet {response.meta.get('tweet_id')}")
                    return
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error in parse_comments: {str(e)}")
            self.logger.debug(f"Response text: {response.text[:200]}")  # 只记录前200个字符
            
            # 重试逻辑
            retry_times = response.meta.get('retry_times', 0)
            if retry_times < 3:  # 最多重试3次
                retry_times += 1
                self.logger.info(f"Retrying comment request (attempt {retry_times})")
                yield scrapy.Request(
                    url=response.url,
                    callback=self.parse_comments,
                    errback=self.errback_httpbin,
                    meta={
                        'tweet_id': response.meta.get('tweet_id'),
                        'retry_times': retry_times,
                        'headers': response.meta.get('headers', {})
                    },
                    dont_filter=True
                )
            else:
                self.logger.error(f"Max retries reached for URL: {response.url}")
    
    def errback_httpbin(self, failure):
        self.logger.error(f"Request failed: {failure.value}")
        # 如果是网络错误，可以在这里添加重试逻辑
        if hasattr(failure.value, 'response'):
            self.logger.error(f"Response status: {failure.value.response.status}")
            self.logger.error(f"Response headers: {failure.value.response.headers}")
            self.logger.error(f"Response body: {failure.value.response.text[:200]}")  # 只记录前200个字符 